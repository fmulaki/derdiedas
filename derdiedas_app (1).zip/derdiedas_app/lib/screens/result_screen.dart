import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../config.dart';
import '../models/word.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'game_screen.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.mode,
    this.deck,
    required this.score,
    required this.correct,
    required this.bestCombo,
    required this.missed,
    required this.isNewBest,
    required this.best,
  });

  final GameMode mode;
  final List<Word>? deck;
  final int score, correct, bestCombo, best;
  final List<Word> missed;
  final bool isNewBest;

  bool get _practice => deck != null;

  String get _message {
    if (_practice) return 'Every correct answer removes a word from your mistakes list.';
    if (score < 5) return 'Good start. Try again!';
    if (score < 15) return 'Very good!';
    if (score < 30) return 'Great! You really know your articles.';
    return 'Wow! German like a native!';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final seen = <String>{};
    final unique = missed.where((w) => seen.add(w.key)).toList();

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 28),
          children: [
            Text(_practice ? 'Practice complete' : 'Game over · ${mode.title}',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: cs.onSurfaceVariant)),
            Text('$score',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 104,
                    fontWeight: FontWeight.w900,
                    color: kBrand,
                    height: 1.1)),
            const Text('points',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
            const SizedBox(height: 14),
            Center(
              child: isNewBest
                  ? Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 8),
                      decoration: BoxDecoration(
                          color: kGold, borderRadius: BorderRadius.circular(99)),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.emoji_events_rounded, color: kInk),
                        SizedBox(width: 6),
                        Text('New best!',
                            style: TextStyle(
                                color: kInk,
                                fontWeight: FontWeight.w900,
                                fontSize: 17)),
                      ]),
                    )
                  : (_practice
                      ? const SizedBox.shrink()
                      : Text('Best: $best',
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 17))),
            ),
            const SizedBox(height: 10),
            Text(_message,
                textAlign: TextAlign.center,
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 16)),
            const SizedBox(height: 22),
            Row(children: [
              Expanded(child: StatTile('$correct', 'correct', color: kDas)),
              const SizedBox(width: 10),
              Expanded(
                  child: StatTile('${missed.length}', 'mistakes', color: kDie)),
              const SizedBox(width: 10),
              Expanded(child: StatTile('$bestCombo', 'best streak')),
            ]),
            if (unique.isNotEmpty) ...[
              const SectionTitle('Learn these words'),
              Container(
                decoration: BoxDecoration(
                    color: cs.surface, borderRadius: BorderRadius.circular(18)),
                child: Column(children: [
                  for (final w in unique)
                    ListTile(
                      title: ArticleWord(w.a, w.w, size: 20),
                      trailing: Text(w.t,
                          style: TextStyle(
                              color: cs.onSurfaceVariant, fontSize: 15)),
                    ),
                ]),
              ),
            ],
            const SizedBox(height: 26),
            FilledButton.icon(
              onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                      builder: (_) => GameScreen(mode: mode, deck: deck))),
              icon: const Icon(Icons.replay_rounded),
              label: const Text('Play again'),
            ),
            const SizedBox(height: 12),
            if (!_practice)
              OutlinedButton.icon(
                onPressed: () => Share.share(
                    'I scored $score points in Der Die Das (${mode.title}) 🔥 '
                    'Can you beat me? #DeutscheMania\n$kStoreUrl'),
                icon: const Icon(Icons.share_rounded),
                label: const Text('Share score'),
              ),
            const SizedBox(height: 6),
            TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Home')),
          ],
        ),
      ),
    );
  }
}
