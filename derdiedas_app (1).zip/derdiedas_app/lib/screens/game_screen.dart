import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../models/word.dart';
import '../services/app_state.dart';
import '../services/sound.dart';
import '../theme.dart';
import 'result_screen.dart';

class GameScreen extends StatefulWidget {
  const GameScreen({super.key, required this.mode, this.deck});

  final GameMode mode;

  /// Nëse jepet, loja përdor vetëm këto fjalë (ushtrimi i gabimeve).
  final List<Word>? deck;

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with TickerProviderStateMixin, WidgetsBindingObserver {
  static const _timeModeMs = 60000.0;

  final _rnd = Random();
  late final Ticker _ticker = createTicker(_onTick);
  late final AnimationController _fly = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 180));
  late final AnimationController _shake = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 420));
  late final Difficulty _diff = app.difficulty;

  List<Word> _bag = [];
  Word? _cur;
  Word? _reveal; // fjala e gabuar që po tregohet
  int _score = 0, _correct = 0, _combo = 0, _bestCombo = 0, _lives = 3;
  final List<Word> _missed = [];
  final List<Word> _right = [];
  late double _limitMs = _diff.startMs.toDouble();
  double _wordLeft = 0, _timeLeft = _timeModeMs;
  Duration _last = Duration.zero;
  bool _paused = false, _over = false, _busy = false;
  int _countdown = 3;
  Timer? _cdTimer;
  Offset _drag = Offset.zero, _flyFrom = Offset.zero, _flyTo = Offset.zero;

  bool get _timeMode => widget.mode == GameMode.time;
  bool get _locked => _over || _paused || _busy || _countdown > 0;
  int get _multiplier => _combo >= 20 ? 3 : (_combo >= 10 ? 2 : 1);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _next();
    _startCountdown();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _cdTimer?.cancel();
    _ticker.dispose();
    _fly.dispose();
    _shake.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _pause();
  }

  // ---------- Rrjedha e lojës ----------
  void _startCountdown() {
    _cdTimer?.cancel();
    setState(() => _countdown = 3);
    Sfx.tick();
    _cdTimer = Timer.periodic(const Duration(milliseconds: 650), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _countdown--);
      if (_countdown <= 0) {
        t.cancel();
        Sfx.start();
        _last = Duration.zero;
        if (!_ticker.isActive) _ticker.start();
      } else {
        Sfx.tick();
      }
    });
  }

  void _onTick(Duration elapsed) {
    final dt = (elapsed - _last).inMicroseconds / 1000.0;
    _last = elapsed;
    if (_locked) return;
    if (_timeMode) {
      _timeLeft -= dt;
      if (_timeLeft <= 0) {
        _timeLeft = 0;
        _finish();
        return;
      }
    } else {
      _wordLeft -= dt;
      if (_wordLeft <= 0) {
        _wordLeft = 0;
        _answer(null); // koha mbaroi = gabim
        return;
      }
    }
    setState(() {});
  }

  void _next() {
    final source = widget.deck ?? app.words;
    if (_bag.isEmpty) {
      _bag = List.of(source)..shuffle(_rnd);
      if (_bag.length > 1 && identical(_bag.last, _cur)) {
        _bag.insert(0, _bag.removeLast());
      }
    }
    _cur = _bag.removeLast();
    _wordLeft = _limitMs;
    _drag = Offset.zero;
  }

  void _answer(String? a) {
    final w = _cur;
    if (w == null || _locked) return;

    if (a == w.a) {
      _correct++;
      _combo++;
      _bestCombo = max(_bestCombo, _combo);
      _score += _multiplier;
      _right.add(w);
      _limitMs = max(_diff.minMs.toDouble(), _limitMs * _diff.factor);
      Sfx.correct();
      final dir = a == 'der'
          ? const Offset(-1, 0)
          : a == 'das'
              ? const Offset(1, 0)
              : const Offset(0, -1);
      _busy = true;
      _flyFrom = _drag;
      _flyTo = dir * 700;
      _fly.forward(from: 0).whenComplete(() {
        if (!mounted || _over) return;
        setState(() {
          _busy = false;
          _next();
        });
      });
      setState(() {});
      return;
    }

    // Gabim ose koha mbaroi
    _combo = 0;
    _missed.add(w);
    Sfx.wrong();
    _shake.forward(from: 0);
    _drag = Offset.zero;
    var ends = false;
    switch (widget.mode) {
      case GameMode.classic:
        ends = true;
      case GameMode.lives:
        _lives--;
        ends = _lives <= 0;
      case GameMode.time:
        _timeLeft = max(0.0, _timeLeft - 3000);
        ends = _timeLeft <= 0;
    }
    _busy = true;
    setState(() => _reveal = w);
    if (ends) {
      _finish();
      return;
    }
    Future.delayed(const Duration(milliseconds: 1000), () {
      if (!mounted || _over) return;
      setState(() {
        _reveal = null;
        _busy = false;
        _next();
      });
    });
  }

  void _finish() {
    if (_over) return;
    _over = true;
    if (_ticker.isActive) _ticker.stop();
    _cdTimer?.cancel();
    final isNew = app.recordGame(
      mode: widget.mode,
      score: _score,
      correct: _correct,
      missed: _missed,
      right: _right,
      practice: widget.deck != null,
    );
    setState(() {});
    Future.delayed(const Duration(milliseconds: 1100), () {
      if (!mounted) return;
      if (isNew && _score > 0) Sfx.record();
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => ResultScreen(
          mode: widget.mode,
          deck: widget.deck,
          score: _score,
          correct: _correct,
          bestCombo: _bestCombo,
          missed: List.of(_missed),
          isNewBest: isNew && _score > 0,
          best: app.best(widget.mode),
        ),
      ));
    });
  }

  void _pause() {
    if (_over || _paused) return;
    _cdTimer?.cancel();
    if (_ticker.isActive) _ticker.stop();
    setState(() => _paused = true);
  }

  void _resume() {
    setState(() => _paused = false);
    _startCountdown();
  }

  void _restart() {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => GameScreen(mode: widget.mode, deck: widget.deck)));
  }

  String? _pick(Offset d) {
    if (d.distance < 70) return null;
    if (-d.dy > d.dx.abs()) return 'die';
    if (d.dx.abs() > d.dy.abs()) return d.dx < 0 ? 'der' : 'das';
    return null;
  }

  // ---------- Pamja ----------
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final progress = _timeMode
        ? _timeLeft / _timeModeMs
        : (_limitMs <= 0 ? 0.0 : _wordLeft / _limitMs);

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _pause();
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(children: [
            Column(children: [
              _topBar(cs),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(
                    value: progress.clamp(0.0, 1.0),
                    minHeight: 10,
                    color: progress < .3 ? kDie : kGold,
                    backgroundColor: cs.surfaceContainerHighest,
                  ),
                ),
              ),
              Expanded(child: _stage(cs)),
              _buttons(),
            ]),
            if (_countdown > 0 && !_paused) _countdownOverlay(),
            if (_paused) _pauseOverlay(cs),
          ]),
        ),
      ),
    );
  }

  Widget _topBar(ColorScheme cs) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 16, 12),
      child: Row(children: [
        SizedBox(
          width: 96,
          child: Align(
            alignment: Alignment.centerLeft,
            child: IconButton(
              onPressed: _pause,
              icon: const Icon(Icons.pause_rounded),
              iconSize: 30,
              tooltip: 'Pause',
            ),
          ),
        ),
        Expanded(
          child: Column(children: [
            Text('$_score',
                style: const TextStyle(
                    fontSize: 42, fontWeight: FontWeight.w900, height: 1)),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: _combo >= 10
                  ? Text('Combo x$_multiplier',
                      key: ValueKey(_multiplier),
                      style: const TextStyle(
                          color: kGold, fontWeight: FontWeight.w900))
                  : Text(widget.deck != null ? 'practice' : 'points',
                      key: const ValueKey(0),
                      style: TextStyle(color: cs.onSurfaceVariant)),
            ),
          ]),
        ),
        SizedBox(
          width: 96,
          child: Align(alignment: Alignment.centerRight, child: _rightInfo(cs)),
        ),
      ]),
    );
  }

  Widget _rightInfo(ColorScheme cs) {
    switch (widget.mode) {
      case GameMode.lives:
        return Row(mainAxisSize: MainAxisSize.min, children: [
          for (var i = 0; i < 3; i++)
            Icon(i < _lives ? Icons.favorite : Icons.favorite_border,
                color: kDie, size: 26),
        ]);
      case GameMode.time:
        return Text('${(_timeLeft / 1000).ceil()}s',
            style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                color: _timeLeft < 10000 ? kDie : cs.onSurface));
      case GameMode.classic:
        return Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Best',
                  style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
              Text('${app.best(widget.mode)}',
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.w900)),
            ]);
    }
  }

  Widget _stage(ColorScheme cs) {
    final hintA = _busy ? null : _pick(_drag);
    return LayoutBuilder(builder: (context, c) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onPanUpdate: (d) {
          if (_locked) return;
          setState(() => _drag += d.delta);
        },
        onPanEnd: (_) {
          if (_locked) return;
          final a = _pick(_drag);
          if (a != null) {
            _answer(a);
          } else {
            setState(() => _drag = Offset.zero);
          }
        },
        child: Stack(alignment: Alignment.center, children: [
          Positioned(left: 12, child: _tray('der', '← der', hintA)),
          Positioned(top: 10, child: _tray('die', '↑ die', hintA)),
          Positioned(right: 12, child: _tray('das', 'das →', hintA)),
          AnimatedBuilder(
            animation: Listenable.merge([_fly, _shake]),
            builder: (context, child) {
              final flying = _busy && _reveal == null;
              final base = flying
                  ? Offset.lerp(_flyFrom, _flyTo,
                      Curves.easeIn.transform(_fly.value))!
                  : _drag;
              final sx =
                  sin(_shake.value * pi * 6) * 14 * (1 - _shake.value);
              final off = base + Offset(sx, 0);
              return Transform.translate(
                offset: off,
                child: Transform.rotate(angle: off.dx / 900, child: child),
              );
            },
            child: _card(cs, hintA, c),
          ),
        ]),
      );
    });
  }

  Widget _tray(String a, String label, String? hintA) {
    return AnimatedScale(
      scale: hintA == a ? 1.18 : 1,
      duration: const Duration(milliseconds: 120),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(
            color: articleColor(a), borderRadius: BorderRadius.circular(99)),
        child: Text(label,
            style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w900,
                fontSize: 16)),
      ),
    );
  }

  Widget _card(ColorScheme cs, String? hintA, BoxConstraints c) {
    final w = _reveal ?? _cur;
    final width = min(c.maxWidth * .66, 280.0);
    final height = min(width * 4 / 3, c.maxHeight - 90);
    final flying = _busy && _reveal == null;
    final fg = flying ? Colors.white : cs.onSurface;

    return Container(
      width: width,
      height: max(height, 160.0),
      decoration: BoxDecoration(
        color: flying && w != null ? articleColor(w.a) : cs.surface,
        borderRadius: BorderRadius.circular(28),
        border: _reveal != null ? Border.all(color: kDie, width: 4) : null,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withAlpha(45),
              blurRadius: 30,
              offset: const Offset(0, 14)),
        ],
      ),
      child: Stack(children: [
        Center(
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (_reveal != null) ...[
                const Text('Correct answer',
                    style: TextStyle(
                        color: kDie, fontWeight: FontWeight.w800)),
                Text(_reveal!.a,
                    style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        color: articleColor(_reveal!.a))),
              ],
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(w?.w ?? '',
                    style: TextStyle(
                        fontSize: 46, fontWeight: FontWeight.w900, color: fg)),
              ),
              if (app.showTranslation && w != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(w.t,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          fontSize: 18,
                          color:
                              flying ? Colors.white70 : cs.onSurfaceVariant)),
                ),
            ]),
          ),
        ),
        if (hintA != null)
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                  color: articleColor(hintA).withAlpha(235),
                  borderRadius: BorderRadius.circular(28)),
              child: Center(
                child: Text(hintA,
                    style: const TextStyle(
                        fontSize: 50,
                        fontWeight: FontWeight.w900,
                        color: Colors.white)),
              ),
            ),
          ),
      ]),
    );
  }

  Widget _buttons() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 16),
      child: Row(children: [
        for (final a in const ['der', 'die', 'das'])
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 5),
              child: SizedBox(
                height: 66,
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: articleColor(a),
                    foregroundColor: Colors.white,
                    minimumSize: const Size(0, 66),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18)),
                    textStyle: const TextStyle(
                        fontSize: 23, fontWeight: FontWeight.w900),
                  ),
                  onPressed: () => _answer(a),
                  child: Text(a),
                ),
              ),
            ),
          ),
      ]),
    );
  }

  Widget _countdownOverlay() {
    return Positioned.fill(
      child: ColoredBox(
        color: Colors.black.withAlpha(110),
        child: Center(
          child: Text('$_countdown',
              style: const TextStyle(
                  fontSize: 120,
                  fontWeight: FontWeight.w900,
                  color: Colors.white)),
        ),
      ),
    );
  }

  Widget _pauseOverlay(ColorScheme cs) {
    return Positioned.fill(
      child: ColoredBox(
        color: Theme.of(context).scaffoldBackgroundColor.withAlpha(245),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.pause_circle_filled_rounded,
                  size: 72, color: kBrand),
              const SizedBox(height: 8),
              const Text('Pause',
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text('Score: $_score',
                  style: TextStyle(color: cs.onSurfaceVariant, fontSize: 17)),
              const SizedBox(height: 28),
              FilledButton.icon(
                  onPressed: _resume,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('Resume')),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                  onPressed: _restart,
                  icon: const Icon(Icons.replay_rounded),
                  label: const Text('Restart')),
              const SizedBox(height: 8),
              TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Quit to menu')),
            ]),
          ),
        ),
      ),
    );
  }
}
