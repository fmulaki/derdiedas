import 'package:flutter/material.dart';

import '../config.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const h = TextStyle(fontSize: 18, fontWeight: FontWeight.w800);
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(22, 8, 22, 32),
        children: const [
          Text('Privacy policy – Der Die Das', style: h),
          SizedBox(height: 10),
          Text(
              'Der Die Das by DeutscheMania does not collect, upload or share any personal data.'),
          SizedBox(height: 16),
          Text('What is stored', style: h),
          SizedBox(height: 6),
          Text(
              'Your best scores, daily streak, missed words and settings are stored only on your device. They are deleted when you uninstall the app or tap "Reset statistics".'),
          SizedBox(height: 16),
          Text('No ads, no accounts', style: h),
          SizedBox(height: 6),
          Text(
              'The app has no ads, needs no account and uses no analytics services.'),
          SizedBox(height: 16),
          Text('Links', style: h),
          SizedBox(height: 6),
          Text(
              'When you open YouTube, Instagram, TikTok or email from the app, those services have their own privacy policies.'),
          SizedBox(height: 16),
          Text('Contact', style: h),
          SizedBox(height: 6),
          Text('Questions: $kEmail'),
        ],
      ),
    );
  }
}
