import 'package:flutter/material.dart';

import '../config.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'game_screen.dart';
import 'how_to_screen.dart';
import 'settings_screen.dart';
import 'stats_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: app,
          builder: (context, _) {
            final top = app.topMistakes();
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
              children: [
                Row(children: [
                  const Spacer(),
                  IconButton(
                    tooltip: 'Statistics',
                    icon: const Icon(Icons.bar_chart_rounded),
                    onPressed: () => go(context, const StatsScreen()),
                  ),
                  IconButton(
                    tooltip: 'Settings',
                    icon: const Icon(Icons.settings_rounded),
                    onPressed: () => go(context, const SettingsScreen()),
                  ),
                ]),
                const SizedBox(height: 8),
                const Logo(size: 34),
                const SizedBox(height: 12),
                Text('Learn German articles by playing',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.onSurfaceVariant, fontSize: 16)),
                const SizedBox(height: 22),
                _StreakCard(),
                const SectionTitle('Choose a mode'),
                for (final m in GameMode.values) _ModeCard(mode: m),
                if (top.isNotEmpty) ...[
                  const SectionTitle('Practice your mistakes'),
                  _Tile(
                    icon: Icons.school_rounded,
                    color: kDie,
                    title: 'Words you got wrong',
                    subtitle:
                        '${top.length} words · play only these until you know them',
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => go(
                        context,
                        GameScreen(
                            mode: GameMode.lives,
                            deck: top.map((e) => e.key).toList())),
                  ),
                ],
                const SizedBox(height: 18),
                OutlinedButton.icon(
                  onPressed: () => go(context, const HowToScreen()),
                  icon: const Icon(Icons.help_outline_rounded),
                  label: const Text('How to play'),
                ),
                const SizedBox(height: 22),
                Center(
                  child: TextButton(
                    onPressed: () => openLink(context, kYoutube),
                    child: Text('More German lessons by DeutscheMania on YouTube',
                        style: TextStyle(color: cs.onSurfaceVariant)),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _StreakCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final s = app.streak;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
          color: kInk, borderRadius: BorderRadius.circular(22)),
      child: Row(children: [
        Icon(Icons.local_fire_department_rounded,
            size: 46, color: app.playedToday ? kGold : Colors.white38),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s == 1 ? '1-day streak' : '$s-day streak',
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900)),
            Text(
                app.playedToday
                    ? 'Nice, you played today!'
                    : 'Play today to keep your streak',
                style: const TextStyle(color: Colors.white70, fontSize: 14)),
          ]),
        ),
        Column(children: [
          Text('${app.bestOverall}',
              style: const TextStyle(
                  color: kGold, fontSize: 24, fontWeight: FontWeight.w900)),
          Text('best',
              style: TextStyle(
                  color: cs.brightness == Brightness.dark
                      ? Colors.white60
                      : Colors.white70,
                  fontSize: 13)),
        ]),
      ]),
    );
  }
}

class _ModeCard extends StatelessWidget {
  const _ModeCard({required this.mode});
  final GameMode mode;

  static const _colors = [kBrand, kDie, kDer];

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return _Tile(
      icon: mode.icon,
      color: _colors[mode.index],
      title: mode.title,
      subtitle: mode.desc,
      trailing: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('${app.best(mode)}',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        Text('best',
            style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
      ]),
      onTap: () => go(context, GameScreen(mode: mode)),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final String title, subtitle;
  final Widget trailing;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: cs.surface,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                    color: color, borderRadius: BorderRadius.circular(16)),
                child: Icon(icon, color: Colors.white, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title,
                          style: const TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text(subtitle,
                          style: TextStyle(
                              fontSize: 14, color: cs.onSurfaceVariant)),
                    ]),
              ),
              const SizedBox(width: 8),
              trailing,
            ]),
          ),
        ),
      ),
    );
  }
}
