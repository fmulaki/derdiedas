import 'package:flutter/material.dart';

import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'home_screen.dart';

class HowToScreen extends StatelessWidget {
  const HowToScreen({super.key, this.first = false});

  /// true kur hapet herën e parë që instalohet aplikacioni
  final bool first;

  void _done(BuildContext context) {
    if (first) {
      app.onboarded = true;
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()));
    } else {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: first ? null : AppBar(title: const Text('How to play')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 24, 22, 28),
          children: [
            if (first) ...[
              const Logo(size: 34),
              const SizedBox(height: 18),
              const Text('Welcome!',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('Every German noun has its own article. Learn them here by playing.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: cs.onSurfaceVariant)),
              const SizedBox(height: 24),
            ],
            _Step(
              color: kDer,
              title: 'der → swipe left',
              text: 'e.g. der Tisch (table), der Hund (dog)',
              icon: Icons.arrow_back_rounded,
            ),
            _Step(
              color: kDie,
              title: 'die → swipe up',
              text: 'e.g. die Lampe (lamp), die Katze (cat)',
              icon: Icons.arrow_upward_rounded,
            ),
            _Step(
              color: kDas,
              title: 'das → swipe right',
              text: 'e.g. das Auto (car), das Buch (book)',
              icon: Icons.arrow_forward_rounded,
            ),
            const SizedBox(height: 6),
            _Info(
                icon: Icons.touch_app_rounded,
                text: 'You can also tap the der, die, das buttons below the card.'),
            _Info(
                icon: Icons.timer_rounded,
                text: 'Every correct answer makes the next word a little faster. Choose your speed in Settings.'),
            _Info(
                icon: Icons.bolt_rounded,
                text: '10 correct in a row = x2 points. 20 in a row = x3 points.'),
            _Info(
                icon: Icons.school_rounded,
                text: 'Words you get wrong are saved. Practice them later in "Practice your mistakes".'),
            _Info(
                icon: Icons.local_fire_department_rounded,
                text: 'Play every day to grow your daily streak.'),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () => _done(context),
              child: Text(first ? 'Start' : 'Got it'),
            ),
          ],
        ),
      ),
    );
  }
}

class _Step extends StatelessWidget {
  const _Step(
      {required this.color,
      required this.title,
      required this.text,
      required this.icon});
  final Color color;
  final String title, text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration:
          BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
      child: Row(children: [
        Icon(icon, color: Colors.white, size: 34),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w900)),
            Text(text, style: const TextStyle(color: Colors.white, fontSize: 15)),
          ]),
        ),
      ]),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: kBrand),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
      ]),
    );
  }
}
