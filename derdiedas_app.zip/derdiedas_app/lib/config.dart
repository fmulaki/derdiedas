/// Të dhënat e aplikacionit dhe linqet e DeutscheMania.
const kAppName = 'Der Die Das';
const kVersion = '1.0.0';
const kPackageId = 'com.deutschemania.derdiedas';
const kStoreUrl = 'https://play.google.com/store/apps/details?id=$kPackageId';

const kYoutube = 'https://www.youtube.com/@Deutsche-mania';
const kInstagram = 'https://www.instagram.com/deutschemania';
const kTiktok = 'https://www.tiktok.com/@deutschemania';
const kEmail = 'deutschemania@gmail.com';
