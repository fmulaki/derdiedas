import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../theme.dart';

/// Logoja: tre kapsula der / die / das.
class Logo extends StatelessWidget {
  const Logo({super.key, this.size = 30});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final a in const ['der', 'die', 'das'])
          Container(
            padding:
                EdgeInsets.symmetric(horizontal: size * .55, vertical: size * .2),
            decoration: BoxDecoration(
                color: articleColor(a),
                borderRadius: BorderRadius.circular(99)),
            child: Text(a,
                style: TextStyle(
                    color: Colors.white,
                    fontSize: size,
                    fontWeight: FontWeight.w900,
                    height: 1.1)),
          ),
      ],
    );
  }
}

/// Fjala me artikullin me ngjyrë, p.sh. "die Lampe".
class ArticleWord extends StatelessWidget {
  const ArticleWord(this.article, this.word, {super.key, this.size = 18});
  final String article, word;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Text.rich(TextSpan(children: [
      TextSpan(
          text: '$article ',
          style: TextStyle(
              color: articleColor(article), fontWeight: FontWeight.w900)),
      TextSpan(text: word, style: const TextStyle(fontWeight: FontWeight.w700)),
    ]), style: TextStyle(fontSize: size));
  }
}

class StatTile extends StatelessWidget {
  const StatTile(this.value, this.label, {super.key, this.color});
  final String value, label;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      decoration: BoxDecoration(
          color: cs.surface, borderRadius: BorderRadius.circular(18)),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        FittedBox(
          child: Text(value,
              style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: color ?? cs.onSurface)),
        ),
        const SizedBox(height: 2),
        Text(label,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant)),
      ]),
    );
  }
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 22, 4, 10),
        child: Text(text,
            style: Theme.of(context)
                .textTheme
                .titleLarge
                ?.copyWith(fontWeight: FontWeight.w800)),
      );
}

void go(BuildContext context, Widget screen) =>
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));

Future<void> openLink(BuildContext context, String url) async {
  final messenger = ScaffoldMessenger.of(context);
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok) {
    messenger.showSnackBar(
        SnackBar(content: Text('Linku nuk u hap: $url')));
  }
}
