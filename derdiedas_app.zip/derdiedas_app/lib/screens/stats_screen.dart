import 'package:flutter/material.dart';

import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'game_screen.dart';

class StatsScreen extends StatelessWidget {
  const StatsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Statistikat')),
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final top = app.topMistakes();
          return ListView(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
            children: [
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: 1.7,
                children: [
                  StatTile('${app.gamesPlayed}', 'lojëra'),
                  StatTile('${app.totalCorrect}', 'përgjigje të sakta',
                      color: kDas),
                  StatTile(app.accuracy ?? '–', 'saktësia'),
                  StatTile('${app.bestStreak}', 'seria më e gjatë (ditë)',
                      color: kGold),
                ],
              ),
              const SectionTitle('Rekordet'),
              Container(
                decoration: BoxDecoration(
                    color: cs.surface, borderRadius: BorderRadius.circular(18)),
                child: Column(children: [
                  for (final m in GameMode.values)
                    ListTile(
                      leading: Icon(m.icon),
                      title: Text(m.title,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      trailing: Text('${app.best(m)}',
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w900)),
                    ),
                ]),
              ),
              const SectionTitle('Fjalët që gabon më shpesh'),
              if (top.isEmpty)
                Text('Ende asnjë gabim. Luaj një lojë dhe këtu do t\'i shohësh fjalët që të ngatërrohen.',
                    style: TextStyle(color: cs.onSurfaceVariant))
              else ...[
                Container(
                  decoration: BoxDecoration(
                      color: cs.surface,
                      borderRadius: BorderRadius.circular(18)),
                  child: Column(children: [
                    for (final e in top)
                      ListTile(
                        title: ArticleWord(e.key.a, e.key.w),
                        subtitle: Text(e.key.t),
                        trailing: Text('${e.value}×',
                            style: const TextStyle(
                                color: kDie, fontWeight: FontWeight.w900)),
                      ),
                  ]),
                ),
                const SizedBox(height: 14),
                FilledButton.icon(
                  onPressed: () => go(
                      context,
                      GameScreen(
                          mode: GameMode.lives,
                          deck: top.map((e) => e.key).toList())),
                  icon: const Icon(Icons.school_rounded),
                  label: const Text('Ushtro këto fjalë'),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}
