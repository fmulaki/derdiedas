import 'package:flutter/material.dart';

import '../config.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'how_to_screen.dart';
import 'privacy_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _confirmReset(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Të fshihen statistikat?'),
        content: const Text(
            'Fshihen rekordet, seria ditore dhe lista e gabimeve. Ky veprim nuk kthehet mbrapsht.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Anulo')),
          FilledButton(
              style: FilledButton.styleFrom(
                  backgroundColor: kDie, minimumSize: const Size(0, 44)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Fshi')),
        ],
      ),
    );
    if (ok == true) {
      await app.resetStats();
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Statistikat u fshinë.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cilësimet')),
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.only(bottom: 28),
          children: [
            const _Header('Loja'),
            SwitchListTile(
              title: const Text('Tingujt'),
              secondary: const Icon(Icons.volume_up_rounded),
              value: app.sound,
              onChanged: (v) => app.sound = v,
            ),
            SwitchListTile(
              title: const Text('Dridhjet'),
              secondary: const Icon(Icons.vibration_rounded),
              value: app.vibration,
              onChanged: (v) => app.vibration = v,
            ),
            SwitchListTile(
              title: const Text('Shfaq përkthimin shqip'),
              secondary: const Icon(Icons.translate_rounded),
              value: app.showTranslation,
              onChanged: (v) => app.showTranslation = v,
            ),
            ListTile(
              leading: const Icon(Icons.speed_rounded),
              title: const Text('Shpejtësia'),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: SegmentedButton<Difficulty>(
                  showSelectedIcon: false,
                  segments: [
                    for (final d in Difficulty.values)
                      ButtonSegment(value: d, label: Text(d.label)),
                  ],
                  selected: {app.difficulty},
                  onSelectionChanged: (s) => app.difficulty = s.first,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.dark_mode_rounded),
              title: const Text('Pamja'),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 10),
                child: SegmentedButton<ThemeMode>(
                  showSelectedIcon: false,
                  segments: const [
                    ButtonSegment(value: ThemeMode.system, label: Text('Sistemi')),
                    ButtonSegment(value: ThemeMode.light, label: Text('E çelët')),
                    ButtonSegment(value: ThemeMode.dark, label: Text('E errët')),
                  ],
                  selected: {app.themeMode},
                  onSelectionChanged: (s) => app.themeMode = s.first,
                ),
              ),
            ),
            const _Header('DeutscheMania'),
            ListTile(
              leading: const Icon(Icons.smart_display_rounded),
              title: const Text('YouTube'),
              subtitle: const Text('Mësime falas: @Deutsche-mania'),
              onTap: () => openLink(context, kYoutube),
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt_rounded),
              title: const Text('Instagram'),
              subtitle: const Text('@deutschemania'),
              onTap: () => openLink(context, kInstagram),
            ),
            ListTile(
              leading: const Icon(Icons.music_note_rounded),
              title: const Text('TikTok'),
              subtitle: const Text('@deutschemania'),
              onTap: () => openLink(context, kTiktok),
            ),
            ListTile(
              leading: const Icon(Icons.mail_rounded),
              title: const Text('Na shkruaj'),
              subtitle: const Text(kEmail),
              onTap: () => openLink(context,
                  'mailto:$kEmail?subject=${Uri.encodeComponent('Der Die Das')}'),
            ),
            ListTile(
              leading: const Icon(Icons.star_rounded),
              title: const Text('Vlerëso aplikacionin'),
              onTap: () => openLink(context, kStoreUrl),
            ),
            const _Header('Të tjera'),
            ListTile(
              leading: const Icon(Icons.help_outline_rounded),
              title: const Text('Si luhet'),
              onTap: () => go(context, const HowToScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.privacy_tip_outlined),
              title: const Text('Politika e privatësisë'),
              onTap: () => go(context, const PrivacyScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: kDie),
              title: const Text('Fshi statistikat',
                  style: TextStyle(color: kDie)),
              onTap: () => _confirmReset(context),
            ),
            const ListTile(
              leading: Icon(Icons.info_outline_rounded),
              title: Text('Versioni'),
              trailing: Text(kVersion),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 6),
        child: Text(text,
            style: TextStyle(
                fontWeight: FontWeight.w800,
                color: Theme.of(context).colorScheme.primary)),
      );
}
