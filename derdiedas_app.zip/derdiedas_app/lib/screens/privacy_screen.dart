import 'package:flutter/material.dart';

import '../config.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const h = TextStyle(fontSize: 18, fontWeight: FontWeight.w800);
    return Scaffold(
      appBar: AppBar(title: const Text('Privatësia')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(22, 8, 22, 32),
        children: const [
          Text('Politika e privatësisë – Der Die Das', style: h),
          SizedBox(height: 10),
          Text(
              'Der Die Das nga DeutscheMania nuk mbledh, nuk ruan në server dhe nuk ndan asnjë të dhënë personale.'),
          SizedBox(height: 16),
          Text('Çfarë ruhet', style: h),
          SizedBox(height: 6),
          Text(
              'Rekordet, seria ditore, fjalët që gabon dhe cilësimet ruhen vetëm në telefonin tënd. Ato fshihen kur e fshin aplikacionin ose kur shtyp "Fshi statistikat".'),
          SizedBox(height: 16),
          Text('Pa reklama, pa llogari', style: h),
          SizedBox(height: 6),
          Text(
              'Aplikacioni nuk ka reklama, nuk kërkon llogari dhe nuk përdor shërbime analitike.'),
          SizedBox(height: 16),
          Text('Linqet', style: h),
          SizedBox(height: 6),
          Text(
              'Kur hap YouTube, Instagram, TikTok ose email nga aplikacioni, ato shërbime kanë politikat e tyre të privatësisë.'),
          SizedBox(height: 16),
          Text('Kontakt', style: h),
          SizedBox(height: 6),
          Text('Për çdo pyetje: $kEmail'),
        ],
      ),
    );
  }
}
