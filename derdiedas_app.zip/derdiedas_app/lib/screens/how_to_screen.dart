import 'package:flutter/material.dart';

import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'home_screen.dart';

class HowToScreen extends StatelessWidget {
  const HowToScreen({super.key, this.first = false});

  /// true kur hapet herën e parë që instalohet aplikacioni
  final bool first;

  void _done(BuildContext context) {
    if (first) {
      app.onboarded = true;
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const HomeScreen()));
    } else {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: first ? null : AppBar(title: const Text('Si luhet')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(22, 24, 22, 28),
          children: [
            if (first) ...[
              const Logo(size: 34),
              const SizedBox(height: 18),
              const Text('Mirë se erdhe!',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('Në gjermanisht çdo emër ka artikullin e vet. Këtu i mëson duke luajtur.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 16, color: cs.onSurfaceVariant)),
              const SizedBox(height: 24),
            ],
            _Step(
              color: kDer,
              title: 'der → rrëshqit majtas',
              text: 'P.sh. der Tisch (tavolinë), der Hund (qen)',
              icon: Icons.arrow_back_rounded,
            ),
            _Step(
              color: kDie,
              title: 'die → rrëshqit lart',
              text: 'P.sh. die Lampe (llambë), die Katze (mace)',
              icon: Icons.arrow_upward_rounded,
            ),
            _Step(
              color: kDas,
              title: 'das → rrëshqit djathtas',
              text: 'P.sh. das Auto (makinë), das Buch (libër)',
              icon: Icons.arrow_forward_rounded,
            ),
            const SizedBox(height: 6),
            _Info(
                icon: Icons.touch_app_rounded,
                text: 'Mund të shtypësh edhe butonat der, die, das poshtë kartës.'),
            _Info(
                icon: Icons.timer_rounded,
                text: 'Çdo përgjigje e saktë e bën fjalën tjetër pak më të shpejtë. Shpejtësinë e zgjedh te Cilësimet.'),
            _Info(
                icon: Icons.bolt_rounded,
                text: '10 përgjigje të sakta rresht = pikë x2. 20 rresht = pikë x3.'),
            _Info(
                icon: Icons.school_rounded,
                text: 'Fjalët që gabon ruhen. I ushtron më vonë te "Ushtro gabimet".'),
            _Info(
                icon: Icons.local_fire_department_rounded,
                text: 'Luaj çdo ditë që ta rritësh serinë ditore.'),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: () => _done(context),
              child: Text(first ? 'Fillo' : 'E kuptova'),
            ),
          ],
        ),
      ),
    );
  }
}

class _Step extends StatelessWidget {
  const _Step(
      {required this.color,
      required this.title,
      required this.text,
      required this.icon});
  final Color color;
  final String title, text;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration:
          BoxDecoration(color: color, borderRadius: BorderRadius.circular(20)),
      child: Row(children: [
        Icon(icon, color: Colors.white, size: 34),
        const SizedBox(width: 14),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 19,
                    fontWeight: FontWeight.w900)),
            Text(text, style: const TextStyle(color: Colors.white, fontSize: 15)),
          ]),
        ),
      ]),
    );
  }
}

class _Info extends StatelessWidget {
  const _Info({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(icon, color: kBrand),
        const SizedBox(width: 12),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
      ]),
    );
  }
}
