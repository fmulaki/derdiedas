import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../config.dart';
import '../models/word.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'game_screen.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.mode,
    this.deck,
    required this.score,
    required this.correct,
    required this.bestCombo,
    required this.missed,
    required this.isNewBest,
    required this.best,
  });

  final GameMode mode;
  final List<Word>? deck;
  final int score, correct, bestCombo, best;
  final List<Word> missed;
  final bool isNewBest;

  bool get _practice => deck != null;

  String get _message {
    if (_practice) return 'Çdo përgjigje e saktë i heq fjalët nga lista e gabimeve.';
    if (score < 5) return 'Fillim i mirë. Provo përsëri!';
    if (score < 15) return 'Shumë mirë!';
    if (score < 30) return 'Super! Je i fortë në artikuj.';
    return 'Wow! Gjermanisht si një vendas!';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final seen = <String>{};
    final unique = missed.where((w) => seen.add(w.key)).toList();

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 28, 20, 28),
          children: [
            Text(_practice ? 'Ushtrimi mbaroi' : 'Loja mbaroi · ${mode.title}',
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: cs.onSurfaceVariant)),
            Text('$score',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 104,
                    fontWeight: FontWeight.w900,
                    color: kBrand,
                    height: 1.1)),
            const Text('pikë',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
            const SizedBox(height: 14),
            Center(
              child: isNewBest
                  ? Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 18, vertical: 8),
                      decoration: BoxDecoration(
                          color: kGold, borderRadius: BorderRadius.circular(99)),
                      child: const Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.emoji_events_rounded, color: kInk),
                        SizedBox(width: 6),
                        Text('Rekord i ri!',
                            style: TextStyle(
                                color: kInk,
                                fontWeight: FontWeight.w900,
                                fontSize: 17)),
                      ]),
                    )
                  : (_practice
                      ? const SizedBox.shrink()
                      : Text('Rekordi: $best',
                          style: const TextStyle(
                              fontWeight: FontWeight.w700, fontSize: 17))),
            ),
            const SizedBox(height: 10),
            Text(_message,
                textAlign: TextAlign.center,
                style: TextStyle(color: cs.onSurfaceVariant, fontSize: 16)),
            const SizedBox(height: 22),
            Row(children: [
              Expanded(child: StatTile('$correct', 'të sakta', color: kDas)),
              const SizedBox(width: 10),
              Expanded(
                  child: StatTile('${missed.length}', 'gabime', color: kDie)),
              const SizedBox(width: 10),
              Expanded(child: StatTile('$bestCombo', 'seria më e gjatë')),
            ]),
            if (unique.isNotEmpty) ...[
              const SectionTitle('Mësoji këto fjalë'),
              Container(
                decoration: BoxDecoration(
                    color: cs.surface, borderRadius: BorderRadius.circular(18)),
                child: Column(children: [
                  for (final w in unique)
                    ListTile(
                      title: ArticleWord(w.a, w.w, size: 20),
                      trailing: Text(w.t,
                          style: TextStyle(
                              color: cs.onSurfaceVariant, fontSize: 15)),
                    ),
                ]),
              ),
            ],
            const SizedBox(height: 26),
            FilledButton.icon(
              onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(
                      builder: (_) => GameScreen(mode: mode, deck: deck))),
              icon: const Icon(Icons.replay_rounded),
              label: const Text('Luaj përsëri'),
            ),
            const SizedBox(height: 12),
            if (!_practice)
              OutlinedButton.icon(
                onPressed: () => Share.share(
                    'Bëra $score pikë në Der Die Das (${mode.title}) 🔥 '
                    'A mund të më mundësh? #DeutscheMania\n$kStoreUrl'),
                icon: const Icon(Icons.share_rounded),
                label: const Text('Ndaj rezultatin'),
              ),
            const SizedBox(height: 6),
            TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Ballina')),
          ],
        ),
      ),
    );
  }
}
