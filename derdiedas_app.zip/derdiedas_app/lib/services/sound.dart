import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';

import 'app_state.dart';

/// Tingujt dhe dridhjet e lojës.
class Sfx {
  static final _c1 = AudioPlayer();
  static final _c2 = AudioPlayer();
  static final _wrong = AudioPlayer();
  static final _tick = AudioPlayer();
  static final _start = AudioPlayer();
  static final _record = AudioPlayer();
  static int _i = 0;

  static Future<void> init() async {
    for (final p in [_c1, _c2, _wrong, _tick, _start, _record]) {
      try {
        await p.setPlayerMode(PlayerMode.lowLatency);
        await p.setReleaseMode(ReleaseMode.stop);
      } catch (_) {}
    }
  }

  static void _play(AudioPlayer p, String file) {
    if (!app.sound) return;
    try {
      p.stop().then((_) => p.play(AssetSource('sounds/$file')));
    } catch (_) {}
  }

  static void correct() {
    _play((_i++).isEven ? _c1 : _c2, 'correct.wav');
    if (app.vibration) HapticFeedback.lightImpact();
  }

  static void wrong() {
    _play(_wrong, 'wrong.wav');
    if (app.vibration) HapticFeedback.heavyImpact();
  }

  static void tick() => _play(_tick, 'tick.wav');
  static void start() => _play(_start, 'start.wav');
  static void record() => _play(_record, 'record.wav');
}
