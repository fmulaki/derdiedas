import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/word.dart';

enum GameMode { classic, lives, time }

extension GameModeX on GameMode {
  String get title => const ['Klasik', '3 jetë', '60 sekonda'][index];
  String get desc => const [
        'Një gabim dhe loja mbaron.',
        'Ke 3 jetë. Çdo gabim të merr një.',
        'Sa më shumë fjalë në 60 sekonda. Çdo gabim të merr 3 sekonda.',
      ][index];
  IconData get icon => const [
        Icons.bolt_rounded,
        Icons.favorite_rounded,
        Icons.timer_rounded,
      ][index];
}

enum Difficulty { easy, normal, hard }

extension DifficultyX on Difficulty {
  String get label => const ['Lehtë', 'Normal', 'Vështirë'][index];

  /// Koha për fjalën e parë (ms)
  int get startMs => const [8000, 6500, 4500][index];

  /// Sa shkurtohet koha pas çdo përgjigje të saktë
  double get factor => const [0.985, 0.98, 0.97][index];

  /// Koha më e shkurtër e mundshme (ms)
  int get minMs => const [3500, 2500, 1500][index];
}

/// Gjendja e aplikacionit: fjalët, cilësimet dhe statistikat.
/// Gjithçka ruhet vetëm në telefon (SharedPreferences).
class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  List<Word> words = [];

  Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    final raw = await rootBundle.loadString('assets/words.json');
    words = (jsonDecode(raw) as List)
        .map((e) => Word.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  // ---------- Cilësimet ----------
  bool _getB(String k, bool d) => _p.getBool(k) ?? d;
  void _setB(String k, bool v) {
    _p.setBool(k, v);
    notifyListeners();
  }

  bool get sound => _getB('sound', true);
  set sound(bool v) => _setB('sound', v);

  bool get vibration => _getB('vibration', true);
  set vibration(bool v) => _setB('vibration', v);

  bool get showTranslation => _getB('translation', true);
  set showTranslation(bool v) => _setB('translation', v);

  bool get onboarded => _getB('onboarded', false);
  set onboarded(bool v) => _setB('onboarded', v);

  Difficulty get difficulty =>
      Difficulty.values[(_p.getInt('difficulty') ?? 1).clamp(0, 2)];
  set difficulty(Difficulty d) {
    _p.setInt('difficulty', d.index);
    notifyListeners();
  }

  ThemeMode get themeMode =>
      ThemeMode.values[(_p.getInt('theme') ?? 0).clamp(0, 2)];
  set themeMode(ThemeMode m) {
    _p.setInt('theme', m.index);
    notifyListeners();
  }

  // ---------- Statistikat ----------
  int best(GameMode m) => _p.getInt('best_${m.name}') ?? 0;
  int get bestOverall => GameMode.values.map(best).reduce(max);
  int get gamesPlayed => _p.getInt('games') ?? 0;
  int get totalCorrect => _p.getInt('correct') ?? 0;
  int get totalWrong => _p.getInt('wrong') ?? 0;
  int get bestStreak => _p.getInt('bestStreak') ?? 0;

  String? get accuracy {
    final t = totalCorrect + totalWrong;
    return t == 0 ? null : '${(totalCorrect * 100 / t).round()}%';
  }

  Map<String, int> get mistakes {
    final s = _p.getString('mistakes');
    if (s == null) return {};
    return (jsonDecode(s) as Map<String, dynamic>)
        .map((k, v) => MapEntry(k, v as int));
  }

  /// Fjalët që gabohen më shpesh, nga më e shpeshta.
  List<MapEntry<Word, int>> topMistakes([int n = 30]) {
    final byKey = {for (final w in words) w.key: w};
    final list = mistakes.entries
        .where((e) => byKey.containsKey(e.key))
        .map((e) => MapEntry(byKey[e.key]!, e.value))
        .toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return list.take(n).toList();
  }

  String _day(DateTime d) => '${d.year}-${d.month}-${d.day}';
  String get _today => _day(DateTime.now());
  String get _yesterday {
    final n = DateTime.now();
    return _day(DateTime(n.year, n.month, n.day - 1));
  }

  /// Sa ditë rresht ka luajtur (0 nëse e ka humbur serinë).
  int get streak {
    final last = _p.getString('lastDay');
    if (last == _today || last == _yesterday) return _p.getInt('streak') ?? 0;
    return 0;
  }

  bool get playedToday => _p.getString('lastDay') == _today;

  void _touchStreak() {
    final last = _p.getString('lastDay');
    if (last == _today) return;
    final s = last == _yesterday ? (_p.getInt('streak') ?? 0) + 1 : 1;
    _p.setInt('streak', s);
    _p.setString('lastDay', _today);
    if (s > bestStreak) _p.setInt('bestStreak', s);
  }

  /// Ruan një lojë të mbaruar. Kthen true nëse është rekord i ri.
  bool recordGame({
    required GameMode mode,
    required int score,
    required int correct,
    required List<Word> missed,
    required List<Word> right,
    required bool practice,
  }) {
    _p.setInt('games', gamesPlayed + 1);
    _p.setInt('correct', totalCorrect + correct);
    _p.setInt('wrong', totalWrong + missed.length);

    final m = mistakes;
    for (final w in missed) {
      m[w.key] = (m[w.key] ?? 0) + 1;
    }
    for (final w in right) {
      final v = m[w.key];
      if (v == null) continue;
      if (v <= 1) {
        m.remove(w.key);
      } else {
        m[w.key] = v - 1;
      }
    }
    _p.setString('mistakes', jsonEncode(m));
    _touchStreak();

    var isNew = false;
    if (!practice && score > best(mode)) {
      _p.setInt('best_${mode.name}', score);
      isNew = true;
    }
    notifyListeners();
    return isNew;
  }

  Future<void> resetStats() async {
    for (final k in [
      'games',
      'correct',
      'wrong',
      'mistakes',
      'streak',
      'bestStreak',
      'lastDay',
      for (final m in GameMode.values) 'best_${m.name}',
    ]) {
      await _p.remove(k);
    }
    notifyListeners();
  }
}

final app = AppState();
