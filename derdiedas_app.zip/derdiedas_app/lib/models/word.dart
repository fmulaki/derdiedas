class Word {
  const Word(this.w, this.a, this.t);

  /// Fjala gjermanisht, p.sh. "Tisch"
  final String w;

  /// Artikulli: der, die ose das
  final String a;

  /// Përkthimi shqip
  final String t;

  String get key => '$a $w';

  factory Word.fromJson(Map<String, dynamic> j) =>
      Word(j['w'] as String, j['a'] as String, j['t'] as String);
}
