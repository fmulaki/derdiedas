import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'config.dart';
import 'screens/home_screen.dart';
import 'screens/how_to_screen.dart';
import 'services/app_state.dart';
import 'services/sound.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await app.init();
  await Sfx.init();
  runApp(const DerDieDasApp());
}

class DerDieDasApp extends StatefulWidget {
  const DerDieDasApp({super.key});

  @override
  State<DerDieDasApp> createState() => _DerDieDasAppState();
}

class _DerDieDasAppState extends State<DerDieDasApp> {
  // Vendoset vetëm një herë, që ekrani i parë të mos ndryshojë gjatë përdorimit.
  late final bool _firstRun = !app.onboarded;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => MaterialApp(
        title: kAppName,
        debugShowCheckedModeBanner: false,
        themeMode: app.themeMode,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: _firstRun ? const HowToScreen(first: true) : const HomeScreen(),
      ),
    );
  }
}
