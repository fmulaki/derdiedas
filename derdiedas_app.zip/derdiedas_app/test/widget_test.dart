import 'dart:convert';
import 'dart:io';

import 'package:derdiedas/models/word.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('words.json: çdo fjalë ka artikull të vlefshëm dhe nuk ka dublime', () {
    final list = (jsonDecode(File('assets/words.json').readAsStringSync())
            as List)
        .map((e) => Word.fromJson(e as Map<String, dynamic>))
        .toList();
    expect(list.length, greaterThan(250));
    expect(list.every((w) => ['der', 'die', 'das'].contains(w.a)), isTrue);
    expect(list.map((w) => w.w).toSet().length, list.length);
  });
}
