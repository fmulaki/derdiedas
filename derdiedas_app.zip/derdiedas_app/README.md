# Der Die Das – aplikacioni Android i DeutscheMania

Lojë për të mësuar artikujt gjermanë (der, die, das), me shpjegime në shqip. E ndërtuar me Flutter.

## Çfarë ka aplikacioni

- **3 mënyra loje:** Klasik (një gabim = fund), 3 jetë, 60 sekonda
- **Ushtro gabimet:** fjalët që gabon ruhen, dhe luan vetëm me to derisa t'i mësosh
- **306 emra** A1–A2, me përkthim shqip (në `assets/words.json`)
- Rrëshqitje me gisht ose butona, numërim 3-2-1, pauzë (edhe automatike kur del nga aplikacioni)
- Kombo: 10 rresht = pikë x2, 20 rresht = x3
- Rekorde për çdo mënyrë, seri ditore, statistika dhe saktësi
- Ekrani i rezultatit me fjalët e gabuara dhe butonin "Ndaj rezultatin"
- Cilësimet: tingujt, dridhjet, përkthimi, shpejtësia (Lehtë/Normal/Vështirë), pamja e çelët/e errët
- Linqe për YouTube, Instagram, TikTok, email dhe vlerësim në Play Store
- Ekrani "Si luhet" në hapjen e parë, politika e privatësisë brenda aplikacionit
- Ikona dhe splash screen
- Pa reklama, pa llogari, pa internet: gjithçka ruhet në telefon

## 1. Përgatitja (një herë)

1. Instalo Flutter: https://docs.flutter.dev/get-started/install (zgjidh Android).
2. Instalo Android Studio dhe Android SDK. Kontrollo me:
   ```
   flutter doctor
   ```

## 2. Hape projektin

Në terminal, brenda dosjes `derdiedas_app`:

```
flutter create --org com.deutschemania --project-name derdiedas --platforms android .
flutter pub get
dart run flutter_launcher_icons
dart run flutter_native_splash:create
```

Komanda e parë krijon dosjet e Android-it që mungojnë. Nuk prek kodin në `lib/`.

## 3. Provoje në telefon

Lidh telefonin me USB (me "USB debugging" të aktivizuar) ose hap një emulator, pastaj:

```
flutter run
```

## 4. Ndërto versionin për Play Store

### a) Krijo çelësin e nënshkrimit (një herë, ruaje mirë!)

```
keytool -genkey -v -keystore ~/deutschemania-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

Ruaje skedarin `.jks` dhe fjalëkalimin në një vend të sigurt. Pa to nuk mund ta përditësosh aplikacionin.

### b) Krijo `android/key.properties`

```
storePassword=FJALËKALIMI
keyPassword=FJALËKALIMI
keyAlias=upload
storeFile=/rruga/e/plotë/deutschemania-upload.jks
```

Mos e ngarko këtë skedar në GitHub.

### c) Lidhe çelësin te `android/app/build.gradle.kts`

Sipër, para `android {`:

```kotlin
import java.util.Properties
import java.io.FileInputStream

val keystoreProperties = Properties()
val keystorePropertiesFile = rootProject.file("key.properties")
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}
```

Brenda `android { ... }`:

```kotlin
signingConfigs {
    create("release") {
        keyAlias = keystoreProperties["keyAlias"] as String
        keyPassword = keystoreProperties["keyPassword"] as String
        storeFile = keystoreProperties["storeFile"]?.let { file(it) }
        storePassword = keystoreProperties["storePassword"] as String
    }
}
buildTypes {
    release {
        signingConfig = signingConfigs.getByName("release")
    }
}
```

(Nëse projekti yt ka `build.gradle` pa `.kts`, shiko: https://docs.flutter.dev/deployment/android#configure-signing-in-gradle)

### d) Ndërto

```
flutter build appbundle --release
```

Skedari për Play Store: `build/app/outputs/bundle/release/app-release.aab`

Për ta provuar si APK në telefon: `flutter build apk --release`

## 5. Publikimi në Google Play

1. Hap llogari zhvilluesi: https://play.google.com/console (pagesë një herë, 25 USD).
2. Krijo aplikacionin "Der Die Das" dhe ngarko `app-release.aab`.
3. Plotëso:
   - **Politika e privatësisë (URL):** Play kërkon një link. Mund të vendosësh tekstin nga `lib/screens/privacy_screen.dart` në faqen tënde të internetit.
   - **Data safety:** "Aplikacioni nuk mbledh dhe nuk ndan të dhëna."
   - **Reklama:** Jo.
   - **Kategoria:** Arsim (Education).
   - **Publiku:** 13 vjeç e lart.
   - **Content rating:** plotëso pyetësorin (asgjë problematike).
4. Grafikat: ikona 512×512 (përdor `assets/icon/icon.png` të zvogëluar), një grafikë 1024×500 dhe të paktën 2 screenshot-e nga telefoni.

### Tekste gati për Play Store

**Emri:** Der Die Das – Artikujt gjermanë

**Përshkrimi i shkurtër (max 80 shkronja):**
Mëso der, die, das duke luajtur. Lojë e shpejtë gjermanishteje për shqipfolës.

**Përshkrimi i plotë:**
Ngatërrohesh me der, die dhe das? Me Der Die Das nga DeutscheMania i mëson artikujt gjermanë duke luajtur, me përkthim në shqip.

Rrëshqit kartën majtas për der, lart për die dhe djathtas për das. Sa më shumë përgjigje të sakta, aq më shpejt vjen fjala tjetër!

• 3 mënyra loje: Klasik, 3 jetë dhe 60 sekonda
• Mbi 300 emra të përditshëm për nivelet A1–A2
• Përkthim shqip për çdo fjalë
• Ushtro fjalët që gabon derisa t'i mësosh
• Kombo, rekorde dhe seri ditore
• Tri shpejtësi: Lehtë, Normal, Vështirë
• Pamje e çelët dhe e errët
• Pa reklama, pa llogari, funksionon pa internet

Krijuar nga DeutscheMania, gjermanisht me shpjegime në shqip. Na gjen në YouTube (@Deutsche-mania), Instagram dhe TikTok (@deutschemania).

## Si të shtosh ose ndryshosh fjalë

Hap `assets/words.json`. Çdo fjalë duket kështu:

```json
{"w": "Tisch", "a": "der", "t": "tavolinë"}
```

`w` = fjala, `a` = artikulli (der/die/das), `t` = përkthimi. Pas ndryshimit, kontrollo me `flutter test`.

## Para çdo përditësimi

Rrit versionin te `pubspec.yaml` (p.sh. `version: 1.0.1+2`) dhe te `lib/config.dart` (`kVersion`).

## Struktura e kodit

```
lib/
  main.dart                 nisja e aplikacionit
  config.dart               versioni dhe linqet
  theme.dart                ngjyrat dhe stili
  models/word.dart          fjala
  services/app_state.dart   cilësimet, rekordet, statistikat
  services/sound.dart       tingujt dhe dridhjet
  screens/                  ekranet: ballina, loja, rezultati, statistikat, cilësimet, si luhet, privatësia
  widgets/common.dart       pjesë të përbashkëta
assets/
  words.json                306 emrat
  sounds/                   tingujt
  icon/                     ikona dhe splash
```
